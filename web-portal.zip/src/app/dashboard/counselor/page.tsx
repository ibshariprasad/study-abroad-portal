export default function CounselorDashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Counselor Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">My Students</h2>
          <p>You have no assigned students.</p>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">Upcoming Appointments</h2>
          <p>No upcoming appointments.</p>
        </div>
      </div>
    </div>
  )
}


import Link from "next/link"
import type React from "react" // Import React

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-blue-600 text-white p-4">
        <h2 className="text-2xl font-bold mb-4">Dashboard</h2>
        <nav>
          <ul className="space-y-2">
            <li>
              <Link href="/dashboard">Overview</Link>
            </li>
            <li>
              <Link href="/dashboard/profile">Profile</Link>
            </li>
            <li>
              <Link href="/dashboard/settings">Settings</Link>
            </li>
            <li>
              <Link href="/">Logout</Link>
            </li>
          </ul>
        </nav>
      </aside>
      <main className="flex-1 p-8">{children}</main>
    </div>
  )
}


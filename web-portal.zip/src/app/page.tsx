import Link from "next/link"

export default function Home() {
  return (
    <div className="text-center">
      <h1 className="text-4xl font-bold mb-4">Welcome to Study Abroad Portal</h1>
      <p className="mb-8">Your gateway to international education opportunities</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link href="/login?role=student" className="bg-blue-500 text-white p-4 rounded hover:bg-blue-600">
          For Students
        </Link>
        <Link href="/login?role=university" className="bg-green-500 text-white p-4 rounded hover:bg-green-600">
          For Universities
        </Link>
        <Link href="/login?role=counselor" className="bg-yellow-500 text-white p-4 rounded hover:bg-yellow-600">
          For Counselors
        </Link>
      </div>
    </div>
  )
}


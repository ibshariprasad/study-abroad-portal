import Link from "next/link"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <div className="z-10 w-full max-w-5xl items-center justify-between font-mono text-sm">
        <h1 className="text-4xl font-bold mb-8">Welcome to My Web Portal</h1>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link href="/" className="text-blue-500 hover:text-blue-700">
                Home
              </Link>
            </li>
            <li>
              <Link href="/about" className="text-blue-500 hover:text-blue-700">
                About
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-blue-500 hover:text-blue-700">
                Contact
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </main>
  )
}


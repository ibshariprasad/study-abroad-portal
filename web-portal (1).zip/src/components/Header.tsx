import Link from "next/link"

export default function Header() {
  return (
    <header className="bg-blue-600 text-white p-4">
      <nav className="flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">
          Study Abroad Portal
        </Link>
        <div>
          <Link href="/login" className="mr-4">
            Login
          </Link>
          <Link href="/register" className="bg-white text-blue-600 px-4 py-2 rounded">
            Register
          </Link>
        </div>
      </nav>
    </header>
  )
}

